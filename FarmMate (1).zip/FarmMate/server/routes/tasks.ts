// server/routes/tasks.ts
import { Router } from 'express';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';
import { query } from '../config/database';

const router = Router();

// GET /api/tasks - Get tasks for authenticated user
router.get('/', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const userUid = req.user?.uid;
    
    if (!userUid) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'User UID not found' 
      });
    }

    // Query tasks for the authenticated user
    const result = await query(
      'SELECT id, user_uid, title, due_date, is_done FROM tasks WHERE user_uid = $1 ORDER BY due_date ASC, id ASC',
      [userUid]
    );

    const tasks = result.rows.map(row => ({
      id: row.id,
      user_uid: row.user_uid,
      title: row.title,
      due_date: row.due_date,
      is_done: row.is_done
    }));

    res.json({
      success: true,
      data: tasks,
      count: tasks.length
    });

  } catch (error: any) {
    console.error('Error fetching tasks:', error);
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: 'Failed to fetch tasks' 
    });
  }
});

// POST /api/tasks - Create a new task for authenticated user
router.post('/', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const userUid = req.user?.uid;
    const { title, due_date, is_done = false } = req.body;
    
    if (!userUid) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'User UID not found' 
      });
    }

    if (!title || !due_date) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'Title and due_date are required' 
      });
    }

    // Insert new task
    const result = await query(
      'INSERT INTO tasks (user_uid, title, due_date, is_done) VALUES ($1, $2, $3, $4) RETURNING *',
      [userUid, title, due_date, is_done]
    );

    const newTask = result.rows[0];

    res.status(201).json({
      success: true,
      data: {
        id: newTask.id,
        user_uid: newTask.user_uid,
        title: newTask.title,
        due_date: newTask.due_date,
        is_done: newTask.is_done
      }
    });

  } catch (error: any) {
    console.error('Error creating task:', error);
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: 'Failed to create task' 
    });
  }
});

// PUT /api/tasks/:id - Update task completion status
router.put('/:id', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const userUid = req.user?.uid;
    const taskId = parseInt(req.params.id);
    const { is_done } = req.body;
    
    if (!userUid) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'User UID not found' 
      });
    }

    if (isNaN(taskId)) {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'Invalid task ID' 
      });
    }

    if (typeof is_done !== 'boolean') {
      return res.status(400).json({ 
        error: 'Bad Request', 
        message: 'is_done must be a boolean' 
      });
    }

    // Update task only if it belongs to the authenticated user
    const result = await query(
      'UPDATE tasks SET is_done = $1 WHERE id = $2 AND user_uid = $3 RETURNING *',
      [is_done, taskId, userUid]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ 
        error: 'Not Found', 
        message: 'Task not found or access denied' 
      });
    }

    const updatedTask = result.rows[0];

    res.json({
      success: true,
      data: {
        id: updatedTask.id,
        user_uid: updatedTask.user_uid,
        title: updatedTask.title,
        due_date: updatedTask.due_date,
        is_done: updatedTask.is_done
      }
    });

  } catch (error: any) {
    console.error('Error updating task:', error);
    res.status(500).json({ 
      error: 'Internal Server Error', 
      message: 'Failed to update task' 
    });
  }
});

export default router;