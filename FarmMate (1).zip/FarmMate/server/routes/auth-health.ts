// server/routes/auth-health.ts
import { Router } from 'express';
import { authenticateToken, AuthenticatedRequest } from '../middleware/auth';
import { query } from '../config/database';

const router = Router();

// Health check endpoint for authenticated API
router.get('/health', authenticateToken, async (req: AuthenticatedRequest, res) => {
  try {
    const userUid = req.user?.uid;
    
    // Test database connection
    const dbResult = await query('SELECT NOW() as current_time');
    
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      user: {
        uid: userUid,
        email: req.user?.email
      },
      database: {
        connected: true,
        server_time: dbResult.rows[0]?.current_time
      },
      firebase: {
        token_verified: true
      }
    });

  } catch (error: any) {
    console.error('Health check error:', error);
    res.status(500).json({ 
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

export default router;