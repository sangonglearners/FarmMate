// src/components/login-dialog.tsx
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { signInWithGoogle } from "@/lib/auth";
import { LogIn, User } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

interface LoginDialogProps {
  children?: React.ReactNode;
}

export function LoginDialog({ children }: LoginDialogProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const { currentUser } = useAuth();

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    try {
      await signInWithGoogle();
      setOpen(false);
    } catch (error) {
      console.error("로그인 오류:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // 이미 로그인된 경우 children을 렌더링
  if (currentUser) {
    return <>{children}</>;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button variant="outline" size="sm">
            <LogIn className="w-4 h-4 mr-2" />
            로그인
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>로그인</DialogTitle>
          <DialogDescription>
            농장 관리 시스템에 로그인하여 모든 기능을 이용하세요.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col space-y-4 pt-4">
          <Button
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full"
            size="lg"
          >
            <User className="w-5 h-5 mr-2" />
            {isLoading ? "로그인 중..." : "Google로 로그인"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}