// src/lib/auth.ts
import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User
} from "firebase/auth";
import { auth, provider } from "./firebase";

// Google 로그인 함수
export const signInWithGoogle = async (): Promise<User | null> => {
  try {
    const result = await signInWithPopup(auth, provider);
    console.log("로그인 성공:", result.user);
    return result.user;
  } catch (error) {
    console.error("로그인 실패:", error);
    throw error;
  }
};

// 로그아웃 함수
export const logOut = async (): Promise<void> => {
  try {
    await signOut(auth);
    console.log("로그아웃 성공");
  } catch (error) {
    console.error("로그아웃 실패:", error);
    throw error;
  }
};

// 인증 상태 변화 감지
export const onAuthStateChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

// 현재 사용자 정보 가져오기
export const getCurrentUser = (): User | null => {
  return auth.currentUser;
};