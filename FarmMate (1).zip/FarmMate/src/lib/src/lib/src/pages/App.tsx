import { useEffect, useState } from 'react';
import { auth } from './lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import LoginPage from './pages/Login';

export default function App() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsubscribe();
  }, []);

  if (!user) return <LoginPage />;

  return (
    <div className="p-4">
      <p>안녕하세요, {user.displayName}</p>
      <button
        onClick={() => signOut(auth)}
        className="bg-red-500 text-white px-4 py-2"
      >
        로그아웃
      </button>
    </div>
  );
}
