import { loginWithGoogle } from '../lib/authService';

export default function LoginPage() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Google 로그인</h1>
      <button
        onClick={async () => {
          try {
            const result = await loginWithGoogle();
            alert(`환영합니다: ${result.user.displayName}`);
          } catch (err) {
            alert('로그인 실패');
          }
        }}
        className="bg-blue-500 text-white px-4 py-2 mt-4"
      >
        Google로 로그인
      </button>
    </div>
  );
}
