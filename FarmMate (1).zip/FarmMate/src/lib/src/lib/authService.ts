import { signInWithPopup, signOut, onAuthStateChanged } from "firebase/auth";
import { auth, provider } from "./firebase";

export const loginWithGoogle = () => signInWithPopup(auth, provider);
export const logout = () => signOut(auth);
export const observeUser = (callback: (user: any) => void) =>
  onAuthStateChanged(auth, (user) => callback(user));