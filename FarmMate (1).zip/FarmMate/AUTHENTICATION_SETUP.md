# Firebase Authentication Setup - Complete Guide

## Overview

This project now includes a complete Node.js Express backend with Firebase ID token authentication, PostgreSQL database integration, and modular API structure.

## Architecture

### Backend Components

1. **Firebase Admin SDK Configuration** (`server/config/firebase-admin.ts`)
   - Initializes Firebase Admin SDK with service account credentials
   - Handles authentication and token verification

2. **Authentication Middleware** (`server/middleware/auth.ts`)
   - Verifies Firebase ID tokens from Authorization headers
   - Extracts user information (UID, email, name)
   - Provides comprehensive error handling

3. **Database Configuration** (`server/config/database.ts`)
   - PostgreSQL connection pool using Replit's DATABASE_URL
   - Helper functions for database queries

4. **Authenticated Routes** (`server/routes/tasks.ts`)
   - Sample authenticated API endpoints
   - User-specific data access based on Firebase UID

## Database Schema

```sql
CREATE TABLE tasks (
  id SERIAL PRIMARY KEY,
  user_uid TEXT NOT NULL,
  title TEXT NOT NULL,
  due_date DATE NOT NULL,
  is_done BOOLEAN NOT NULL DEFAULT false
);
```

## API Endpoints

### Authentication Required Endpoints

All endpoints under `/api/auth/*` require a valid Firebase ID token in the Authorization header.

#### GET `/api/auth/health`
Health check endpoint that verifies authentication and database connectivity.

**Headers:**
```
Authorization: Bearer <firebase_id_token>
```

**Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-01-06T12:25:26.000Z",
  "user": {
    "uid": "firebase-user-uid",
    "email": "user@example.com"
  },
  "database": {
    "connected": true,
    "server_time": "2025-01-06T12:25:26.000Z"
  },
  "firebase": {
    "token_verified": true
  }
}
```

#### GET `/api/auth/tasks`
Retrieve tasks for the authenticated user.

**Headers:**
```
Authorization: Bearer <firebase_id_token>
```

**Response:**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "user_uid": "firebase-user-uid",
      "title": "토마토 물주기",
      "due_date": "2025-01-06",
      "is_done": false
    }
  ],
  "count": 1
}
```

#### POST `/api/auth/tasks`
Create a new task for the authenticated user.

**Headers:**
```
Authorization: Bearer <firebase_id_token>
Content-Type: application/json
```

**Body:**
```json
{
  "title": "새로운 작업",
  "due_date": "2025-01-07",
  "is_done": false
}
```

#### PUT `/api/auth/tasks/:id`
Update task completion status.

**Headers:**
```
Authorization: Bearer <firebase_id_token>
Content-Type: application/json
```

**Body:**
```json
{
  "is_done": true
}
```

## Error Responses

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Missing or invalid authorization header"
}
```

### 400 Bad Request
```json
{
  "error": "Bad Request",
  "message": "Title and due_date are required"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "Failed to fetch tasks"
}
```

## Testing the API

### 1. Get Firebase ID Token from Frontend

In your React app, after successful Google sign-in:

```javascript
import { auth } from './lib/firebase';

// Get the current user's ID token
const user = auth.currentUser;
if (user) {
  const idToken = await user.getIdToken();
  console.log('ID Token:', idToken);
}
```

### 2. Test with cURL

```bash
# Health check
curl -X GET http://localhost:5000/api/auth/health \
  -H "Authorization: Bearer <your_firebase_id_token>"

# Get tasks
curl -X GET http://localhost:5000/api/auth/tasks \
  -H "Authorization: Bearer <your_firebase_id_token>"

# Create task
curl -X POST http://localhost:5000/api/auth/tasks \
  -H "Authorization: Bearer <your_firebase_id_token>" \
  -H "Content-Type: application/json" \
  -d '{"title": "Test Task", "due_date": "2025-01-07"}'
```

### 3. Frontend Integration Example

```javascript
// API client with authentication
const apiRequest = async (endpoint, options = {}) => {
  const user = auth.currentUser;
  if (!user) throw new Error('User not authenticated');
  
  const token = await user.getIdToken();
  
  const response = await fetch(`/api/auth${endpoint}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  
  if (!response.ok) {
    throw new Error(`API Error: ${response.status}`);
  }
  
  return response.json();
};

// Usage
const tasks = await apiRequest('/tasks');
const newTask = await apiRequest('/tasks', {
  method: 'POST',
  body: JSON.stringify({
    title: 'New Task',
    due_date: '2025-01-07'
  })
});
```

## Security Features

1. **Firebase ID Token Verification**: All tokens are verified against Firebase Auth
2. **User Isolation**: Each user can only access their own data
3. **Input Validation**: All request bodies are validated
4. **Error Handling**: Comprehensive error responses without exposing internals
5. **Database Security**: Parameterized queries prevent SQL injection

## Development Notes

- Service account key is stored in `serviceAccountKey.json` (keep secure!)
- Database URL is automatically configured from Replit environment
- Firebase Admin SDK initializes automatically on server start
- All authenticated routes are prefixed with `/api/auth/`

## Next Steps

1. Add more authenticated endpoints as needed
2. Implement role-based access control if required
3. Add request rate limiting
4. Set up proper logging and monitoring
5. Add API documentation (OpenAPI/Swagger)