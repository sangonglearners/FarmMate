import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import AddCropDialog from "@/components/add-crop-dialog";
import CropCard from "@/components/crop-card";
import type { Crop } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export default function Crops() {
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [editingCrop, setEditingCrop] = useState<Crop | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: crops, isLoading } = useQuery<Crop[]>({
    queryKey: ["/api/crops", searchQuery ? { search: searchQuery } : {}],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/crops/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/crops"] });
      toast({
        title: "작물 삭제 완료",
        description: "작물이 성공적으로 삭제되었습니다.",
      });
    },
    onError: () => {
      toast({
        title: "삭제 실패",
        description: "작물 삭제 중 오류가 발생했습니다.",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (crop: Crop) => {
    if (confirm(`"${crop.category} > ${crop.name} > ${crop.variety}" 작물을 삭제하시겠습니까?`)) {
      deleteMutation.mutate(crop.id);
    }
  };

  const handleEdit = (crop: Crop) => {
    setEditingCrop(crop);
    setShowAddDialog(true);
  };

  const handleDialogClose = () => {
    setShowAddDialog(false);
    setEditingCrop(null);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'growing':
        return 'bg-green-500';
      case 'harvesting':
        return 'bg-purple-500';
      case 'completed':
        return 'bg-red-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'growing':
        return '성장 중';
      case 'harvesting':
        return '수확 대기';
      case 'completed':
        return '수확 완료';
      default:
        return '알 수 없음';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">내 작물 관리</h1>
        <p className="text-gray-600">나의 대표 작물을 관리해 보세요</p>
      </div>

      {/* Search */}
      <div className="mb-8">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            placeholder="작물 이름을 검색해 주세요 (ex. 양배추)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[1, 2, 3, 4].map(i => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="w-20 h-20 bg-gray-200 rounded-lg mx-auto mb-4"></div>
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mx-auto w-16"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : crops && crops.length > 0 ? (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {crops.map(crop => (
              <CropCard 
                key={crop.id} 
                crop={crop} 
                onEdit={handleEdit} 
                onDelete={handleDelete}
                getStatusColor={getStatusColor}
                getStatusText={getStatusText}
              />
            ))}
          </div>
        </>
      ) : (
        <div className="text-center py-12">
          <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center mx-auto mb-4">
            <div className="w-12 h-12 bg-gray-400 rounded"></div>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">
            {searchQuery ? "검색 결과가 없습니다" : "작물이 없습니다"}
          </h3>
          <p className="text-gray-600 mb-6">
            {searchQuery ? "다른 검색어로 시도해보세요" : "첫 번째 작물을 추가해보세요"}
          </p>
        </div>
      )}

      <div className="text-center">
        <Button onClick={() => setShowAddDialog(true)} size="lg">
          <Plus className="w-5 h-5 mr-2" />
          작물 추가하기
        </Button>
      </div>

      <AddCropDialog
        open={showAddDialog}
        onOpenChange={handleDialogClose}
        crop={editingCrop}
      />
    </div>
  );
}
