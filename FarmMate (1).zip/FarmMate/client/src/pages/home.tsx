import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Calendar as CalendarIcon, Plus, ChevronLeft, ChevronRight, Calculator, Edit2, CheckCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import TaskCard from "@/components/task-card";
import NewAddTaskDialog from "@/components/new-add-task-dialog";
import { EditTaskDialog } from "@/components/edit-task-dialog";
import { LoginDialog } from "../components/login-dialog";
import { UserMenu } from "../components/user-menu";
import { useAuth } from "../contexts/AuthContext";
import type { Task, Farm, Crop } from "@shared/schema";

export default function Home() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState<'2week' | 'month'>('2week');
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [isAddTaskOpen, setIsAddTaskOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const { currentUser } = useAuth();

  const selectedDateStr = selectedDate.toISOString().split('T')[0];

  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });
  
  const { data: farms } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
  });

  const { data: crops } = useQuery<Crop[]>({
    queryKey: ["/api/crops"],
  });

  // Filter tasks for selected date and group them
  const selectedDateTasks = tasks?.filter(task => task.scheduledDate === selectedDateStr) || [];
  
  // Group tasks by crop and task type
  const groupedTasks = selectedDateTasks.reduce((groups, task) => {
    const crop = crops?.find(c => c.id === task.cropId);
    const key = `${crop?.name || '작물'}-${task.taskType}`;
    
    if (!groups[key]) {
      groups[key] = {
        title: task.title,
        taskType: task.taskType,
        cropName: crop?.name || '작물',
        farmName: farms?.find(f => f.id === task.farmId)?.name,
        tasks: [],
        rows: []
      };
    }
    
    groups[key].tasks.push(task);
    
    // Extract row number from description
    const rowMatch = task.description?.match(/이랑: (\d+)번/);
    if (rowMatch) {
      groups[key].rows.push(parseInt(rowMatch[1]));
    }
    
    return groups;
  }, {} as Record<string, {
    title: string;
    taskType: string;
    cropName: string;
    farmName?: string;
    tasks: Task[];
    rows: number[];
  }>);

  const groupedTaskArray = Object.values(groupedTasks);

  const today = new Date();
  const currentYear = currentDate.getFullYear();
  const currentMonth = currentDate.getMonth();
  
  // Get current month name in Korean
  const monthNames = ['1월', '2월', '3월', '4월', '5월', '6월', 
                     '7월', '8월', '9월', '10월', '11월', '12월'];

  // Generate calendar days based on view mode
  const generateCalendarDays = () => {
    if (viewMode === '2week') {
      // 2주 보기: 현재 주와 다음 주
      const days = [];
      const startOfWeek = new Date(currentDate);
      const dayOfWeek = startOfWeek.getDay();
      const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // 월요일 시작
      startOfWeek.setDate(startOfWeek.getDate() + mondayOffset);
      
      for (let i = 0; i < 14; i++) {
        const day = new Date(startOfWeek);
        day.setDate(startOfWeek.getDate() + i);
        days.push(day);
      }
      return days;
    } else {
      // 한달 보기
      const firstDayOfMonth = new Date(currentYear, currentMonth, 1);
      const lastDayOfMonth = new Date(currentYear, currentMonth + 1, 0);
      const daysInMonth = lastDayOfMonth.getDate();
      const startingDay = firstDayOfMonth.getDay();
      const adjustedStartingDay = startingDay === 0 ? 6 : startingDay - 1;
      
      const days = [];
      
      // 빈 칸 추가
      for (let i = 0; i < adjustedStartingDay; i++) {
        days.push(null);
      }
      
      // 실제 날짜 추가
      for (let day = 1; day <= daysInMonth; day++) {
        days.push(new Date(currentYear, currentMonth, day));
      }
      
      return days;
    }
  };

  const calendarDays = generateCalendarDays();

  const navigateCalendar = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    if (viewMode === '2week') {
      newDate.setDate(newDate.getDate() + (direction === 'next' ? 14 : -14));
    } else {
      newDate.setMonth(newDate.getMonth() + (direction === 'next' ? 1 : -1));
    }
    setCurrentDate(newDate);
  };

  const isToday = (date: Date | null) => {
    if (!date) return false;
    return date.toDateString() === today.toDateString();
  };

  const isSelectedDate = (date: Date | null) => {
    if (!date) return false;
    return date.toDateString() === selectedDate.toDateString();
  };

  const getTasksForDate = (date: Date | null) => {
    if (!date || !tasks) return [];
    const dateStr = date.toISOString().split('T')[0];
    return tasks.filter(task => task.scheduledDate === dateStr);
  };

  const formatSelectedDate = () => {
    const year = selectedDate.getFullYear().toString().slice(2);
    const month = (selectedDate.getMonth() + 1).toString().padStart(2, '0');
    const day = selectedDate.getDate().toString().padStart(2, '0');
    return `${year}${month}${day}`;
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header with Login */}
      <header className="flex justify-between items-center px-4 py-4 border-b">
        <h1 className="text-xl font-bold text-gray-900">FarmMate</h1>
        {currentUser ? (
          <UserMenu />
        ) : (
          <LoginDialog>
            <Button variant="outline" size="sm">
              로그인
            </Button>
          </LoginDialog>
        )}
      </header>

      {/* Hero Section - Mobile First */}
      <section className="px-4 py-8 text-center">
        <h2 className="text-lg text-gray-700 mb-4">
          이번 시즌에는<br />
          <span className="text-primary font-semibold">무엇을, 언제, 어디에, 얼마나</span> 심지?
        </h2>
        <LoginDialog>
          <Button className="w-full max-w-xs mx-auto bg-primary hover:bg-primary/90">
            작물 추천 받으러가기
          </Button>
        </LoginDialog>
      </section>

      {/* Today's Planner */}
      <section className="px-4 pb-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-gray-900">오늘의 플래너</h3>
          <Button 
            variant="ghost" 
            size="icon"
            onClick={() => setIsAddTaskOpen(true)}
          >
            <Calculator className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Calendar */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateCalendar('prev')}
              >
                <ChevronLeft className="w-5 h-5" />
              </Button>
              
              <h4 className="font-semibold text-gray-900">
                {currentYear}년 {monthNames[currentMonth]}
              </h4>
              
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigateCalendar('next')}
              >
                <ChevronRight className="w-5 h-5" />
              </Button>
            </div>
            
            {viewMode === '2week' ? (
              // 2주 보기
              <div className="space-y-2">
                <div className="grid grid-cols-7 gap-1 text-center text-xs text-gray-500 mb-2">
                  {['월', '화', '수', '목', '금', '토', '일'].map(day => (
                    <div key={day} className="py-1 font-medium">{day}</div>
                  ))}
                </div>
                
                {/* 첫째 주 */}
                <div className="grid grid-cols-7 gap-1">
                  {calendarDays.slice(0, 7).map((date, index) => {
                    const dayTasks = getTasksForDate(date);
                    return (
                      <button
                        key={index}
                        onClick={() => date && setSelectedDate(date)}
                        className={`
                          h-10 text-xs rounded transition-colors relative
                          ${isToday(date) ? "bg-primary text-white" : "hover:bg-gray-100"}
                          ${isSelectedDate(date) ? "ring-2 ring-primary ring-offset-1" : ""}
                        `}
                      >
                        {date?.getDate()}
                        {dayTasks.length > 0 && (
                          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2">
                            <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
                
                {/* 둘째 주 */}
                <div className="grid grid-cols-7 gap-1">
                  {calendarDays.slice(7, 14).map((date, index) => {
                    const dayTasks = getTasksForDate(date);
                    return (
                      <button
                        key={index + 7}
                        onClick={() => date && setSelectedDate(date)}
                        className={`
                          h-10 text-xs rounded transition-colors relative
                          ${isToday(date) ? "bg-primary text-white" : "hover:bg-gray-100"}
                          ${isSelectedDate(date) ? "ring-2 ring-primary ring-offset-1" : ""}
                        `}
                      >
                        {date?.getDate()}
                        {dayTasks.length > 0 && (
                          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2">
                            <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              // 한달 보기
              <div className="grid grid-cols-7 gap-1 text-center text-sm">
                <div className="grid grid-cols-7 gap-1 text-center text-xs text-gray-500 mb-2 col-span-7">
                  {['월', '화', '수', '목', '금', '토', '일'].map(day => (
                    <div key={day} className="py-1 font-medium">{day}</div>
                  ))}
                </div>
                
                {calendarDays.map((date, index) => {
                  if (date === null) {
                    return <div key={index} className="h-8"></div>;
                  }
                  
                  const dayTasks = getTasksForDate(date);
                  return (
                    <button
                      key={index}
                      onClick={() => setSelectedDate(date)}
                      className={`
                        h-8 text-xs rounded transition-colors relative
                        ${isToday(date) ? "bg-primary text-white" : "hover:bg-gray-100"}
                        ${isSelectedDate(date) ? "ring-2 ring-primary ring-offset-1" : ""}
                      `}
                    >
                      {date.getDate()}
                      {dayTasks.length > 0 && (
                        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2">
                          <div className="w-1 h-1 bg-green-500 rounded-full"></div>
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
            
            <div className="flex justify-center mt-4">
              {viewMode === '2week' ? (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setViewMode('month')}
                >
                  한달 보기
                </Button>
              ) : (
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setViewMode('2week')}
                >
                  간략히 보기
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Selected Date Schedule */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-4">
            <h4 className="font-semibold text-gray-900">
              일정 ({formatSelectedDate()})
            </h4>
            <Button 
              size="sm" 
              onClick={() => setIsAddTaskOpen(true)}
            >
              <Plus className="w-4 h-4 mr-1" />
              일정 추가하기
            </Button>
          </div>
          
          {tasksLoading ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="animate-pulse">
                  <div className="h-16 bg-gray-200 rounded-lg"></div>
                </div>
              ))}
            </div>
          ) : groupedTaskArray.length > 0 ? (
            <div className="space-y-3">
              {/* 미완료 작업들을 먼저 표시 */}
              {groupedTaskArray
                .filter(group => !group.tasks.every(task => task.completed === 1))
                .map((group, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        {/* 완료 체크박스 */}
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-6 h-6 rounded-full"
                          onClick={async () => {
                            const isCompleted = group.tasks.every(task => task.completed === 1);
                            const newCompleted = isCompleted ? 0 : 1;
                            for (const task of group.tasks) {
                              await fetch(`/api/tasks/${task.id}`, {
                                method: "PATCH",
                                headers: { "Content-Type": "application/json" },
                                body: JSON.stringify({ completed: newCompleted }),
                              });
                            }
                            window.location.reload();
                          }}
                        >
                          <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                            group.tasks.every(task => task.completed === 1) ? 'bg-green-500' : 'bg-green-100'
                          }`}>
                            <CheckCircle className={`w-3 h-3 ${
                              group.tasks.every(task => task.completed === 1) ? 'text-white' : 'text-green-600'
                            }`} />
                          </div>
                        </Button>

                        {/* 작업 종류별 색상 구분 */}
                        <div className={`w-3 h-3 rounded-full ${
                          group.taskType === '파종' ? 'bg-green-500' :
                          group.taskType === '육묘' ? 'bg-blue-500' :
                          group.taskType === '정식' ? 'bg-yellow-500' :
                          group.taskType === '풀/병해충/수분 관리' ? 'bg-orange-500' :
                          group.taskType === '수확-선별' ? 'bg-purple-500' :
                          group.taskType === '저장-포장' ? 'bg-red-500' :
                          'bg-gray-500'
                        }`}></div>
                        
                        <div className="flex-1">
                          <h5 className={`font-medium ${
                            group.tasks.every(task => task.completed === 1) 
                              ? 'text-gray-500 line-through' 
                              : 'text-gray-900'
                          }`}>
                            {group.cropName} {group.taskType}
                            {group.rows.length > 1 && ` - 이랑 ${group.rows.sort((a, b) => a - b).join(', ')}`}
                            {group.rows.length === 1 && ` - 이랑 ${group.rows[0]}`}
                          </h5>
                          <div className="flex items-center space-x-2 text-xs text-gray-500 mt-1">
                            {group.farmName && <span>{group.farmName}</span>}
                            <span>• {group.tasks.length}개 작업</span>
                          </div>
                        </div>
                      </div>
                      
                      <EditTaskDialog
                        task={group.tasks[0]}
                        trigger={
                          <Button variant="ghost" size="icon">
                            <Edit2 className="w-4 h-4" />
                          </Button>
                        }
                      />
                    </div>
                  </CardContent>
                </Card>
              ))}
              
              {/* 완료된 작업들을 하단에 표시 */}
              {groupedTaskArray
                .filter(group => group.tasks.every(task => task.completed === 1))
                .length > 0 && (
                <>
                  <div className="border-t pt-4 mt-6">
                    <h5 className="text-sm font-medium text-gray-500 mb-3">완료된 작업</h5>
                  </div>
                  {groupedTaskArray
                    .filter(group => group.tasks.every(task => task.completed === 1))
                    .map((group, index) => (
                    <Card key={`completed-${index}`} className="opacity-60 bg-gray-50">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            {/* 완료 체크박스 */}
                            <Button
                              variant="ghost"
                              size="icon"
                              className="w-6 h-6 rounded-full"
                              onClick={async () => {
                                const isCompleted = group.tasks.every(task => task.completed === 1);
                                const newCompleted = isCompleted ? 0 : 1;
                                for (const task of group.tasks) {
                                  await fetch(`/api/tasks/${task.id}`, {
                                    method: "PATCH",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({ completed: newCompleted }),
                                  });
                                }
                                window.location.reload();
                              }}
                            >
                              <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                                group.tasks.every(task => task.completed === 1) ? 'bg-green-500' : 'bg-green-100'
                              }`}>
                                <CheckCircle className={`w-3 h-3 ${
                                  group.tasks.every(task => task.completed === 1) ? 'text-white' : 'text-green-600'
                                }`} />
                              </div>
                            </Button>

                            {/* 작업 종류별 색상 구분 */}
                            <div className={`w-3 h-3 rounded-full ${
                              group.taskType === '파종' ? 'bg-green-500' :
                              group.taskType === '육묘' ? 'bg-blue-500' :
                              group.taskType === '정식' ? 'bg-yellow-500' :
                              group.taskType === '풀/병해충/수분 관리' ? 'bg-orange-500' :
                              group.taskType === '수확-선별' ? 'bg-purple-500' :
                              group.taskType === '저장-포장' ? 'bg-red-500' :
                              'bg-gray-500'
                            }`}></div>
                            
                            <div className="flex-1">
                              <h5 className="font-medium text-gray-500 line-through">
                                {group.cropName} {group.taskType}
                                {group.rows.length > 1 && ` - 이랑 ${group.rows.sort((a, b) => a - b).join(', ')}`}
                                {group.rows.length === 1 && ` - 이랑 ${group.rows[0]}`}
                              </h5>
                              <div className="flex items-center space-x-2 text-xs text-gray-400 mt-1">
                                {group.farmName && <span>{group.farmName}</span>}
                                <span>• {group.tasks.length}개 작업 완료</span>
                              </div>
                            </div>
                          </div>
                          
                          <EditTaskDialog
                            task={group.tasks[0]}
                            trigger={
                              <Button variant="ghost" size="icon" className="opacity-50">
                                <Edit2 className="w-4 h-4" />
                              </Button>
                            }
                          />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </>
              )}
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <CalendarIcon className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500 mb-4">이 날짜에는 예정된 작업이 없습니다</p>
                <Button onClick={() => setIsAddTaskOpen(true)}>
                  <Plus className="w-4 h-4 mr-2" />
                  일정 추가하기
                </Button>
              </CardContent>
            </Card>
          )}
        </div>


      </section>

      <NewAddTaskDialog
        open={isAddTaskOpen}
        onOpenChange={setIsAddTaskOpen}
        selectedDate={selectedDate.toISOString().split('T')[0]}
      />
      
      {editingTask && (
        <EditTaskDialog
          task={editingTask}
        />
      )}
    </div>
  );
}