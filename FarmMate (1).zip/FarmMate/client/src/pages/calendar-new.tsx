import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Task, Farm, Crop } from "@shared/schema";

export default function Calendar() {
  const [viewMode, setViewMode] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedEnvironment, setSelectedEnvironment] = useState<string>('노지');
  const [currentMonth, setCurrentMonth] = useState(7); // 7월
  const [currentYear, setCurrentYear] = useState(2025);
  const [currentStartDay, setCurrentStartDay] = useState(1);

  const { data: tasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: farms } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
  });

  const { data: crops } = useQuery<Crop[]>({
    queryKey: ["/api/crops"],
  });

  const rowCount = selectedEnvironment === '노지' ? 43 : selectedEnvironment === '시설1' ? 20 : 10;

  // 월간 뷰에서 날짜 계산 (월말과 다음 달 초를 연결)
  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month, 0).getDate();
  };

  const getDisplayDays = () => {
    const daysInCurrentMonth = getDaysInMonth(currentMonth, currentYear);
    const days = [];
    
    // 현재 달의 날짜들
    for (let i = currentStartDay; i <= Math.min(currentStartDay + 9, daysInCurrentMonth); i++) {
      days.push({ day: i, month: currentMonth, isCurrentMonth: true });
    }
    
    // 다음 달 날짜로 10개 채우기
    if (days.length < 10) {
      const nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
      const remaining = 10 - days.length;
      for (let i = 1; i <= remaining; i++) {
        days.push({ day: i, month: nextMonth, isCurrentMonth: false });
      }
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      if (currentMonth === 1) {
        setCurrentMonth(12);
        setCurrentYear(prev => prev - 1);
      } else {
        setCurrentMonth(prev => prev - 1);
      }
    } else {
      if (currentMonth === 12) {
        setCurrentMonth(1);
        setCurrentYear(prev => prev + 1);
      } else {
        setCurrentMonth(prev => prev + 1);
      }
    }
    setCurrentStartDay(1);
  };

  const navigateDays = (direction: 'prev' | 'next') => {
    setCurrentStartDay(prev => {
      if (direction === 'prev') {
        return Math.max(prev - 5, 1);
      } else {
        const daysInMonth = getDaysInMonth(currentMonth, currentYear);
        return Math.min(prev + 5, daysInMonth - 9);
      }
    });
  };

  const navigateYear = (direction: 'prev' | 'next') => {
    setCurrentYear(prev => direction === 'prev' ? prev - 1 : prev + 1);
  };

  const handleNavigation = (direction: 'prev' | 'next') => {
    if (viewMode === 'monthly') {
      navigateDays(direction);
    } else {
      navigateYear(direction);
    }
  };

  const handleMonthNavigation = (direction: 'prev' | 'next') => {
    navigateMonth(direction);
  };

  const displayDays = getDisplayDays();

  // 샘플 작물 데이터 생성 (이미지 기반)
  const getSampleCropData = (rowIndex: number, dayIndex: number) => {
    const crops = [
      { name: '배추', color: 'bg-green-200', textColor: 'text-green-800' },
      { name: '상추', color: 'bg-blue-200', textColor: 'text-blue-800' },
      { name: '콜라비', color: 'bg-purple-200', textColor: 'text-purple-800' },
      { name: '당근', color: 'bg-orange-200', textColor: 'text-orange-800' },
      { name: '토마토', color: 'bg-red-200', textColor: 'text-red-800' },
      { name: '오이', color: 'bg-green-300', textColor: 'text-green-900' },
    ];

    // 이미지와 유사한 패턴으로 작물 배치
    if (rowIndex === 0 && dayIndex >= 1 && dayIndex <= 6) return crops[0]; // 배추
    if (rowIndex === 1 && dayIndex >= 0 && dayIndex <= 9) return crops[1]; // 상추
    if (rowIndex === 2 && dayIndex >= 2 && dayIndex <= 7) return crops[2]; // 콜라비
    if (rowIndex === 3 && dayIndex >= 3 && dayIndex <= 9) return crops[3]; // 당근
    if (rowIndex === 6 && dayIndex >= 1 && dayIndex <= 4) return crops[4]; // 토마토
    if (rowIndex === 6 && dayIndex >= 5 && dayIndex <= 6) return crops[5]; // 오이
    if (rowIndex === 6 && dayIndex >= 7 && dayIndex <= 9) return crops[0]; // 배추
    if (rowIndex === 7 && dayIndex >= 0 && dayIndex <= 2) return crops[4]; // 토마토
    if (rowIndex === 7 && dayIndex >= 3 && dayIndex <= 4) return crops[5]; // 오이
    if (rowIndex === 7 && dayIndex >= 7 && dayIndex <= 9) return crops[0]; // 배추
    if (rowIndex === 8 && dayIndex >= 0 && dayIndex <= 9) return crops[0]; // 배추 (큰 블록)
    if (rowIndex === 10 && dayIndex >= 1 && dayIndex <= 9) return crops[0]; // 배추
    if (rowIndex === 11 && dayIndex >= 6 && dayIndex <= 9) return crops[2]; // 콜라비
    
    return null;
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-20 md:pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">나의 영농일지</h1>
          <p className="text-sm text-gray-500 mb-4">
            오늘의 업무와 예간 일을 일정을 확인할 수 있습니다.
          </p>
          
          <div className="flex items-center justify-between">
            {/* 재배환경 선택 */}
            <Select value={selectedEnvironment} onValueChange={setSelectedEnvironment}>
              <SelectTrigger className="w-32 border-2 border-blue-500">
                <SelectValue placeholder="재배환경" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="노지">노지</SelectItem>
                <SelectItem value="시설1">시설1</SelectItem>
                <SelectItem value="시설2">시설2</SelectItem>
              </SelectContent>
            </Select>

            {/* 뷰 모드 전환 */}
            <div className="flex bg-gray-200 rounded-full p-1">
              <button
                onClick={() => setViewMode('monthly')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  viewMode === 'monthly'
                    ? 'bg-white text-gray-900 shadow'
                    : 'text-gray-600'
                }`}
              >
                월간
              </button>
              <button
                onClick={() => setViewMode('yearly')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  viewMode === 'yearly'
                    ? 'bg-white text-gray-900 shadow'
                    : 'text-gray-600'
                }`}
              >
                연간
              </button>
            </div>
          </div>
        </div>

        {/* Month Navigation for Monthly View */}
        {viewMode === 'monthly' && (
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleMonthNavigation('prev')}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            <h2 className="text-lg font-semibold">
              {currentYear}년 {currentMonth}월
            </h2>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleMonthNavigation('next')}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Calendar Grid */}
        <Card className="shadow-sm">
          <CardContent className="p-0">
            {viewMode === 'monthly' ? (
              // 월간 뷰
              <div className="overflow-x-auto">
                <div className="min-w-full">
                  {/* 네비게이션 */}
                  <div className="flex items-center justify-center py-4 border-b">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleNavigation('prev')}
                      className="mr-4"
                    >
                      &lt; PREV
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleNavigation('next')}
                      className="ml-4"
                    >
                      NEXT &gt;
                    </Button>
                  </div>

                  {/* 헤더 - 이랑/일 */}
                  <div className="grid grid-cols-11 border-b bg-gray-50">
                    <div className="p-3 text-xs font-medium text-gray-600 border-r">
                      이랑/일
                    </div>
                    {displayDays.map((dayInfo, i) => (
                      <div key={i} className="p-3 text-xs font-medium text-center border-r last:border-r-0">
                        {dayInfo.day}
                      </div>
                    ))}
                  </div>

                  {/* 이랑별 작물 표시 */}
                  <div className="divide-y">
                    {Array.from({ length: Math.min(rowCount, 15) }, (_, rowIndex) => (
                      <div key={rowIndex} className="grid grid-cols-11">
                        <div className="p-3 text-sm font-medium text-gray-700 border-r bg-gray-50">
                          {rowIndex + 1}
                        </div>
                        
                        {displayDays.map((dayInfo, dayIndex) => {
                          const cropData = getSampleCropData(rowIndex, dayIndex);
                          
                          return (
                            <div key={dayIndex} className="p-2 border-r last:border-r-0 min-h-[60px] flex items-center">
                              {cropData && (
                                <div className={`w-full h-8 rounded ${cropData.color} flex items-center justify-center`}>
                                  <span className={`text-xs font-medium ${cropData.textColor}`}>
                                    {cropData.name}
                                  </span>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              // 연간 뷰
              <div className="overflow-x-auto">
                <div className="min-w-full">
                  {/* 연도 네비게이션 */}
                  <div className="flex items-center justify-between py-4 px-6 border-b">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => navigateYear('prev')}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    
                    <h2 className="text-lg font-semibold">{currentYear}년</h2>
                    
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => navigateYear('next')}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* 헤더 - 이랑/월 */}
                  <div className="grid grid-cols-13 border-b bg-gray-50">
                    <div className="p-3 text-xs font-medium text-gray-600 border-r">
                      이랑/월
                    </div>
                    {Array.from({ length: 12 }, (_, i) => (
                      <div key={i} className="p-3 text-xs font-medium text-center border-r last:border-r-0">
                        {i + 1}
                      </div>
                    ))}
                  </div>

                  {/* 이랑별 연간 작물 재배 현황 */}
                  <div className="divide-y">
                    {Array.from({ length: Math.min(rowCount, 15) }, (_, rowIndex) => (
                      <div key={rowIndex} className="grid grid-cols-13">
                        <div className="p-3 text-sm font-medium text-gray-700 border-r bg-gray-50">
                          {rowIndex + 1}
                        </div>
                        
                        {Array.from({ length: 12 }, (_, monthIndex) => {
                          // 연간 뷰를 위한 더 연속적인 작물 데이터
                          const getContinuousCrop = () => {
                            if (rowIndex === 0 && monthIndex >= 0 && monthIndex <= 5) return { name: '배추', color: 'bg-green-200' };
                            if (rowIndex === 3 && monthIndex >= 2 && monthIndex <= 7) return { name: '콜라비', color: 'bg-purple-200' };
                            if (rowIndex === 3 && monthIndex >= 8 && monthIndex <= 10) return { name: '토마토', color: 'bg-pink-200' };
                            if (rowIndex === 3 && monthIndex >= 11) return { name: '청경채', color: 'bg-green-300' };
                            if (rowIndex === 6 && monthIndex >= 1 && monthIndex <= 3) return { name: '비트', color: 'bg-orange-200' };
                            if (rowIndex === 6 && monthIndex >= 5 && monthIndex <= 6) return { name: '순무', color: 'bg-yellow-200' };
                            if (rowIndex === 7 && monthIndex >= 5 && monthIndex <= 9) return { name: '배추', color: 'bg-green-200' };
                            if (rowIndex === 8 && monthIndex >= 0 && monthIndex <= 11) return { name: '배추', color: 'bg-green-200' };
                            if (rowIndex === 11 && monthIndex >= 9) return { name: '토마토', color: 'bg-pink-200' };
                            return null;
                          };

                          const cropData = getContinuousCrop();
                          
                          return (
                            <div key={monthIndex} className="p-2 border-r last:border-r-0 min-h-[50px] flex items-center">
                              {cropData && (
                                <div className={`w-full h-6 rounded ${cropData.color} flex items-center justify-center`}>
                                  <span className="text-xs font-medium text-gray-800">
                                    {cropData.name}
                                  </span>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}