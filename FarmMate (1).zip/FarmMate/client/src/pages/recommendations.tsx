import { useQuery } from "@tanstack/react-query";
import { Lightbulb, MapPin, Thermometer, Droplets } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import type { CropRecommendation, Farm } from "@shared/schema";

export default function Recommendations() {
  const { data: recommendations, isLoading } = useQuery<CropRecommendation[]>({
    queryKey: ["/api/recommendations"],
  });

  const { data: farms } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
  });

  if (isLoading) {
    return (
      <div className="p-4">
        <div className="h-8 bg-gray-200 rounded mb-4 animate-pulse"></div>
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="h-32 bg-gray-200 rounded animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-xl font-bold text-gray-900 mb-2">작물 추천</h1>
        <p className="text-gray-600 text-sm">AI가 분석한 최적의 작물을 추천해드립니다</p>
      </div>

      {/* Introduction Card */}
      <Card className="bg-gradient-to-r from-green-50 to-blue-50">
        <CardContent className="p-6 text-center">
          <Lightbulb className="w-12 h-12 text-primary mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-gray-900 mb-2">
            스마트 작물 추천 시스템
          </h2>
          <p className="text-gray-600 text-sm">
            농장 환경, 날씨, 시장 동향을 분석하여<br />
            최적의 작물을 추천해드립니다
          </p>
        </CardContent>
      </Card>

      {/* Farm Status */}
      {farms && farms.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-900">내 농장 현황</h3>
          {farms.map(farm => (
            <Card key={farm.id}>
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <MapPin className="w-4 h-4 text-gray-500" />
                      <h4 className="font-medium text-gray-900">{farm.name}</h4>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{farm.location}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>{farm.environment === 'outdoor' ? '노지' : '시설'}</span>
                      <span>{farm.size}㎡</span>
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    분석 완료
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Recommendations */}
      <div className="space-y-4">
        <h3 className="font-semibold text-gray-900">추천 작물</h3>
        
        {recommendations && recommendations.length > 0 ? (
          <div className="space-y-4">
            {recommendations.map(rec => (
              <Card key={rec.id} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-4 bg-gradient-to-r from-green-500 to-green-600 text-white">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-lg">{rec.cropName}</h4>
                        <p className="text-green-100 text-sm">{rec.variety}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold">{rec.score}점</div>
                        <div className="text-green-100 text-xs">추천도</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="p-4 space-y-3">
                    <div>
                      <h5 className="font-medium text-gray-900 mb-2">추천 이유</h5>
                      <p className="text-sm text-gray-600">{rec.reason}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center space-x-2">
                        <Thermometer className="w-4 h-4 text-orange-500" />
                        <span className="text-gray-600">재배 난이도</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Droplets className="w-4 h-4 text-blue-500" />
                        <span className="text-gray-600">수분 관리</span>
                      </div>
                    </div>
                    
                    <div className="pt-3 border-t">
                      <Button className="w-full" size="sm">
                        이 작물로 계획 세우기
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="p-8 text-center">
              <Lightbulb className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h4 className="font-medium text-gray-900 mb-2">추천 준비 중</h4>
              <p className="text-gray-500 text-sm mb-4">
                농장 정보를 분석하여 최적의 작물을 추천해드릴게요
              </p>
              {(!farms || farms.length === 0) && (
                <div className="text-xs text-gray-400">
                  * 농장을 먼저 등록해주세요
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Tips Section */}
      <Card className="bg-blue-50">
        <CardContent className="p-4">
          <h4 className="font-medium text-gray-900 mb-2">💡 추천 팁</h4>
          <ul className="text-sm text-gray-600 space-y-1">
            <li>• 계절과 기후를 고려한 작물을 선택하세요</li>
            <li>• 연작 피해를 방지하기 위해 작물 순환을 계획하세요</li>
            <li>• 시장 가격과 수요를 확인해보세요</li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}