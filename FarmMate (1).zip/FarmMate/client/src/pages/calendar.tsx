import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import type { Task, Farm, Crop } from "@shared/schema";

export default function Calendar() {
  const [viewMode, setViewMode] = useState<'monthly' | 'yearly'>('monthly');
  const [selectedEnvironment, setSelectedEnvironment] = useState<string>('노지');
  const [currentMonth, setCurrentMonth] = useState(new Date().getMonth() + 1);
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const [currentStartDay, setCurrentStartDay] = useState(() => {
    const today = new Date();
    const todayDate = today.getDate();
    let startDay = 1;
    while (startDay + 9 < todayDate) {
      startDay += 5;
    }
    return startDay;
  });

  const { data: tasks } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
  });

  const { data: farms } = useQuery<Farm[]>({
    queryKey: ["/api/farms"],
  });

  const { data: crops } = useQuery<Crop[]>({
    queryKey: ["/api/crops"],
  });

  const rowCount = selectedEnvironment === '노지' ? 40 : selectedEnvironment === '시설1' ? 20 : 10;

  // 월간 뷰에서 날짜 계산 (월말과 다음 달 초를 연결)
  const getDaysInMonth = (month: number, year: number) => {
    return new Date(year, month, 0).getDate();
  };

  const getDisplayDays = () => {
    const daysInCurrentMonth = getDaysInMonth(currentMonth, currentYear);
    const days = [];
    
    // 현재 달의 날짜들
    for (let i = currentStartDay; i <= Math.min(currentStartDay + 9, daysInCurrentMonth); i++) {
      days.push({ day: i, month: currentMonth, isCurrentMonth: true });
    }
    
    // 다음 달 날짜로 10개 채우기
    if (days.length < 10) {
      const nextMonth = currentMonth === 12 ? 1 : currentMonth + 1;
      const remaining = 10 - days.length;
      for (let i = 1; i <= remaining; i++) {
        days.push({ day: i, month: nextMonth, isCurrentMonth: false });
      }
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    if (direction === 'prev') {
      if (currentMonth === 1) {
        setCurrentMonth(12);
        setCurrentYear(prev => prev - 1);
      } else {
        setCurrentMonth(prev => prev - 1);
      }
    } else {
      if (currentMonth === 12) {
        setCurrentMonth(1);
        setCurrentYear(prev => prev + 1);
      } else {
        setCurrentMonth(prev => prev + 1);
      }
    }
    setCurrentStartDay(1);
  };

  const navigateDays = (direction: 'prev' | 'next') => {
    setCurrentStartDay(prev => {
      if (direction === 'prev') {
        return Math.max(prev - 5, 1);
      } else {
        const daysInMonth = getDaysInMonth(currentMonth, currentYear);
        // 월말에 도달하면 다음 달로 이동
        if (prev + 5 > daysInMonth) {
          navigateMonth('next');
          return 1;
        }
        return Math.min(prev + 5, daysInMonth - 9);
      }
    });
  };

  const navigateYear = (direction: 'prev' | 'next') => {
    setCurrentYear(prev => direction === 'prev' ? prev - 1 : prev + 1);
  };

  const handleNavigation = (direction: 'prev' | 'next') => {
    if (viewMode === 'monthly') {
      navigateDays(direction);
    } else {
      navigateYear(direction);
    }
  };

  const handleMonthNavigation = (direction: 'prev' | 'next') => {
    navigateMonth(direction);
  };

  const displayDays = getDisplayDays();

  // 오늘 날짜 확인
  const isToday = (day: number, month: number) => {
    const today = new Date();
    return today.getDate() === day && (today.getMonth() + 1) === month && today.getFullYear() === currentYear;
  };

  // 실제 작물/농장 데이터에서 작물 기간 계산
  const getCropPeriods = () => {
    if (!crops || !farms || !tasks) return [];
    
    const periods: Array<{
      rowIndex: number;
      startDay: number;
      endDay: number;
      crop: { name: string; color: string };
    }> = [];

    // 현재 환경에 맞는 농장 찾기
    const currentFarm = farms.find(farm => 
      farm.environment === selectedEnvironment || 
      (selectedEnvironment === '노지' && farm.name.includes('노지'))
    );

    if (!currentFarm) return periods;

    // 작물별로 재배 기간 계산
    crops.forEach((crop, cropIndex) => {
      const cropTasks = tasks.filter(task => 
        task.cropId === crop.id && 
        task.farmId === currentFarm.id
      );

      if (cropTasks.length > 0) {
        // 파종/정식 날짜와 수확 날짜 찾기
        const plantingTasks = cropTasks.filter(task => 
          task.taskType === '파종' || task.taskType === '정식'
        );
        const harvestTasks = cropTasks.filter(task => 
          task.taskType === '수확'
        );

        if (plantingTasks.length > 0) {
          const startDate = new Date(Math.min(...plantingTasks.map(t => new Date(t.scheduledDate).getTime())));
          const endDate = harvestTasks.length > 0 
            ? new Date(Math.max(...harvestTasks.map(t => new Date(t.scheduledDate).getTime())))
            : new Date(startDate.getTime() + 30 * 24 * 60 * 60 * 1000); // 30일 후

          // 현재 표시 기간과 겹치는지 확인
          if (startDate.getMonth() + 1 === currentMonth || endDate.getMonth() + 1 === currentMonth) {
            const startDay = startDate.getMonth() + 1 === currentMonth ? startDate.getDate() : 1;
            const endDay = endDate.getMonth() + 1 === currentMonth ? endDate.getDate() : getDaysInMonth(currentMonth, currentYear);

            // 작물별 색상 지정
            const colors = [
              'bg-green-200', 'bg-blue-200', 'bg-yellow-200', 'bg-purple-200', 
              'bg-orange-200', 'bg-pink-200', 'bg-indigo-200', 'bg-red-200'
            ];

            periods.push({
              rowIndex: cropIndex % rowCount,
              startDay,
              endDay,
              crop: {
                name: crop.name || crop.category,
                color: colors[cropIndex % colors.length]
              }
            });
          }
        }
      }
    });

    return periods;
  };

  // 실제 작업 데이터에서 농작업 가져오기
  const getWorkData = (rowIndex: number, dayIndex: number) => {
    if (!tasks || !crops || !farms) return null;

    const currentDay = displayDays[dayIndex];
    const currentDate = new Date(currentYear, currentDay.month - 1, currentDay.day);
    const dateStr = currentDate.toISOString().split('T')[0];
    
    // 현재 환경에 맞는 농장 찾기
    const currentFarm = farms.find(farm => 
      farm.environment === selectedEnvironment || 
      (selectedEnvironment === '노지' && farm.name.includes('노지'))
    );

    if (!currentFarm) return null;

    // 해당 날짜와 이랑에 맞는 작업 찾기
    const dayTasks = tasks.filter(task => {
      const isSameDate = task.scheduledDate === dateStr;
      const isSameFarm = task.farmId === currentFarm.id;
      
      // 이랑 번호를 description에서 추출
      const rowMatch = task.description?.match(/이랑: (\d+)번/);
      const assignedRow = rowMatch ? parseInt(rowMatch[1]) - 1 : null; // 0-based index로 변환
      
      return isSameDate && isSameFarm && assignedRow === rowIndex;
    });

    if (dayTasks.length === 0) return null;

    // 첫 번째 작업의 색상 결정 및 작물명 포함
    const task = dayTasks[0];
    const crop = crops.find(c => c.id === task.cropId);
    const workColors: Record<string, { color: string; textColor: string }> = {
      '파종': { color: 'bg-amber-600', textColor: 'text-white' },
      '정식': { color: 'bg-blue-600', textColor: 'text-white' },
      '수확': { color: 'bg-yellow-500', textColor: 'text-black' },
      '수확-선별': { color: 'bg-yellow-500', textColor: 'text-black' },
      '저장-포장': { color: 'bg-gray-600', textColor: 'text-white' },
      '육묘': { color: 'bg-green-600', textColor: 'text-white' },
    };

    return {
      name: `${crop?.name || '작물'} ${task.taskType}`,
      taskType: task.taskType,
      cropName: crop?.name,
      ...(workColors[task.taskType] || { color: 'bg-gray-500', textColor: 'text-white' })
    };
  };

  // 작업 기간 계산 (여러 날에 걸친 작업)
  const getWorkPeriods = () => {
    if (!tasks || !crops || !farms) return [];
    
    const periods: Array<{
      rowIndex: number;
      startDay: number;
      endDay: number;
      work: { name: string; color: string; textColor: string };
    }> = [];

    // 현재 환경에 맞는 농장 찾기
    const currentFarm = farms.find(farm => 
      farm.environment === selectedEnvironment || 
      (selectedEnvironment === '노지' && farm.name.includes('노지'))
    );

    if (!currentFarm) return periods;

    // 날짜 범위별로 작업 그룹화
    const workGroups: Record<string, any[]> = {};
    
    tasks.forEach(task => {
      if (task.farmId !== currentFarm.id) return;
      
      const taskDate = new Date(task.scheduledDate);
      if (taskDate.getMonth() + 1 !== currentMonth) return;
      
      // 이랑 번호를 description에서 추출
      const rowMatch = task.description?.match(/이랑: (\d+)번/);
      const assignedRow = rowMatch ? parseInt(rowMatch[1]) - 1 : 0; // 0-based index로 변환
      
      const crop = crops.find(c => c.id === task.cropId);
      const key = `${assignedRow}-${task.taskType}-${task.cropId}`;
      if (!workGroups[key]) {
        workGroups[key] = [];
      }
      workGroups[key].push({ ...task, assignedRow, date: taskDate, cropName: crop?.name });
    });

    // 각 그룹을 연속된 기간으로 변환
    Object.values(workGroups).forEach(group => {
      if (group.length === 0) return;
      
      // 날짜별로 정렬
      group.sort((a, b) => a.date.getTime() - b.date.getTime());
      
      const workColors: Record<string, { color: string; textColor: string }> = {
        '파종': { color: 'bg-amber-600', textColor: 'text-white' },
        '정식': { color: 'bg-blue-600', textColor: 'text-white' },
        '수확': { color: 'bg-yellow-500', textColor: 'text-black' },
        '수확·선별': { color: 'bg-yellow-500', textColor: 'text-black' },
        '저장·포장': { color: 'bg-gray-600', textColor: 'text-white' },
        '육묘': { color: 'bg-green-600', textColor: 'text-white' },
      };

      const firstTask = group[0];
      const lastTask = group[group.length - 1];
      
      periods.push({
        rowIndex: firstTask.assignedRow,
        startDay: firstTask.date.getDate(),
        endDay: lastTask.date.getDate(),
        work: {
          name: `${firstTask.cropName || '작물'} ${firstTask.taskType}`,
          taskType: firstTask.taskType,
          cropName: firstTask.cropName,
          ...(workColors[firstTask.taskType] || { color: 'bg-gray-500', textColor: 'text-white' })
        }
      });
    });

    return periods;
  };

  // 특정 날짜에 작물이 표시되어야 하는지 확인 (첫 번째 날에만 표시)
  const shouldShowCrop = (rowIndex: number, dayIndex: number) => {
    const periods = getCropPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    return period && dayIndex === period.startDay - 1; // 첫 번째 날에만 표시
  };

  // 특정 날짜에 작업이 표시되어야 하는지 확인 (첫 번째 날에만 표시)
  const shouldShowWork = (rowIndex: number, dayIndex: number) => {
    const periods = getWorkPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    return period && dayIndex === period.startDay - 1; // 첫 번째 날에만 표시
  };

  // 작물 블록의 너비 계산 (며칠에 걸쳐 표시되는지)
  const getCropSpan = (rowIndex: number, dayIndex: number) => {
    const periods = getCropPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    if (period && dayIndex === period.startDay - 1) {
      return Math.min(period.endDay - period.startDay + 1, 10 - dayIndex); // 화면 끝까지만
    }
    return 1;
  };

  // 작업 블록의 너비 계산 (며칠에 걸쳐 표시되는지)
  const getWorkSpan = (rowIndex: number, dayIndex: number) => {
    const periods = getWorkPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    if (period && dayIndex === period.startDay - 1) {
      return Math.min(period.endDay - period.startDay + 1, 10 - dayIndex); // 화면 끝까지만
    }
    return 1;
  };

  // 작물 데이터 가져오기
  const getCropData = (rowIndex: number, dayIndex: number) => {
    const periods = getCropPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    return period?.crop || null;
  };

  // 작업 데이터 가져오기
  const getWorkDataForPeriod = (rowIndex: number, dayIndex: number) => {
    const periods = getWorkPeriods();
    const period = periods.find(p => p.rowIndex === rowIndex && dayIndex >= p.startDay - 1 && dayIndex <= p.endDay - 1);
    return period?.work || null;
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16 pb-20 md:pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">나의 영농일지</h1>
          <p className="text-sm text-gray-500 mb-4">
            오늘의 업무와 예간 일을 일정을 확인할 수 있습니다.
          </p>
          
          <div className="flex items-center justify-between">
            {/* 재배환경 선택 */}
            <Select value={selectedEnvironment} onValueChange={setSelectedEnvironment}>
              <SelectTrigger className="w-32 border-2 border-blue-500">
                <SelectValue placeholder="재배환경" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="노지">노지</SelectItem>
                <SelectItem value="시설1">시설1</SelectItem>
                <SelectItem value="시설2">시설2</SelectItem>
              </SelectContent>
            </Select>

            {/* 뷰 모드 전환 */}
            <div className="flex bg-gray-200 rounded-full p-1">
              <button
                onClick={() => setViewMode('monthly')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  viewMode === 'monthly'
                    ? 'bg-white text-gray-900 shadow'
                    : 'text-gray-600'
                }`}
              >
                월간
              </button>
              <button
                onClick={() => setViewMode('yearly')}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-colors ${
                  viewMode === 'yearly'
                    ? 'bg-white text-gray-900 shadow'
                    : 'text-gray-600'
                }`}
              >
                연간
              </button>
            </div>
          </div>
        </div>

        {/* Month Navigation for Monthly View */}
        {viewMode === 'monthly' && (
          <div className="flex items-center justify-between mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleMonthNavigation('prev')}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            
            <h2 className="text-lg font-semibold">
              {currentYear}년 {currentMonth}월
            </h2>
            
            <Button
              variant="ghost"
              size="icon"
              onClick={() => handleMonthNavigation('next')}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Calendar Grid */}
        <Card className="shadow-sm">
          <CardContent className="p-0">
            {viewMode === 'monthly' ? (
              // 월간 뷰
              <div className="overflow-x-auto">
                <div className="min-w-full">
                  {/* 네비게이션 */}
                  <div className="flex items-center justify-center py-4 border-b">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleNavigation('prev')}
                      className="mr-4"
                    >
                      &lt; PREV
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleNavigation('next')}
                      className="ml-4"
                    >
                      NEXT &gt;
                    </Button>
                  </div>

                  {/* 헤더 - 이랑/일 */}
                  <div className="grid grid-cols-11 border-b bg-gray-50">
                    <div className="p-3 text-xs font-medium text-gray-600 border-r">
                      이랑/일
                    </div>
                    {displayDays.map((dayInfo, i) => {
                      const todayClass = isToday(dayInfo.day, dayInfo.month) 
                        ? 'bg-green-100 text-green-800 font-bold' 
                        : '';
                      return (
                        <div key={i} className={`p-3 text-xs font-medium text-center border-r last:border-r-0 ${todayClass}`}>
                          {dayInfo.day}
                        </div>
                      );
                    })}
                  </div>

                  {/* 이랑별 작물/농작업 표시 */}
                  <div className="divide-y max-h-[600px] overflow-y-auto">
                    {Array.from({ length: rowCount }, (_, rowIndex) => (
                      <div key={rowIndex} className="grid grid-cols-11">
                        <div className="p-3 text-sm font-medium text-gray-700 border-r bg-gray-50 sticky left-0">
                          {rowIndex + 1}
                        </div>
                        
                        {displayDays.map((dayInfo, dayIndex) => {
                          const cropData = getCropData(rowIndex, dayIndex);
                          const workData = getWorkDataForPeriod(rowIndex, dayIndex);
                          const showCrop = shouldShowCrop(rowIndex, dayIndex);
                          const showWork = shouldShowWork(rowIndex, dayIndex);
                          const cropSpan = getCropSpan(rowIndex, dayIndex);
                          const workSpan = getWorkSpan(rowIndex, dayIndex);
                          const todayClass = isToday(dayInfo.day, dayInfo.month) 
                            ? 'bg-green-50' 
                            : '';
                          
                          return (
                            <div key={dayIndex} className={`p-1 border-r last:border-r-0 min-h-[80px] relative ${todayClass}`}>
                              {/* 작물 표시 (위쪽) */}
                              {showCrop && cropData && (
                                <div 
                                  className={`absolute top-1 left-1 h-8 rounded ${cropData.color} flex items-center justify-center border border-gray-400`}
                                  style={{ 
                                    width: `calc(${cropSpan * 100}% + ${(cropSpan - 1) * 8}px)`,
                                    zIndex: 10 
                                  }}
                                >
                                  <span className="text-xs font-medium text-gray-800">
                                    {cropData.name}
                                  </span>
                                </div>
                              )}
                              
                              {/* 작물 배경 표시 (텍스트 없는 연속 블록) */}
                              {!showCrop && cropData && (
                                <div 
                                  className={`absolute top-1 left-1 right-1 h-8 rounded ${cropData.color} border border-gray-400`}
                                  style={{ zIndex: 5 }}
                                />
                              )}
                              
                              {/* 농작업 표시 (아래쪽) */}
                              {showWork && workData && (
                                <div 
                                  className={`absolute bottom-1 left-1 h-6 rounded text-xs flex items-center justify-center font-medium ${workData.color} ${workData.textColor} border border-gray-300`}
                                  style={{ 
                                    width: `calc(${workSpan * 100}% + ${(workSpan - 1) * 8}px)`,
                                    zIndex: 10 
                                  }}
                                >
                                  {workData.name}
                                </div>
                              )}
                              
                              {/* 작업 배경 표시 (텍스트 없는 연속 블록) */}
                              {!showWork && workData && (
                                <div 
                                  className={`absolute bottom-1 left-1 right-1 h-6 rounded ${workData.color} border border-gray-300`}
                                  style={{ zIndex: 5 }}
                                />
                              )}
                            </div>
                          );
                        })}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              // 연간 뷰
              <div className="overflow-x-auto">
                <div className="min-w-full">
                  {/* 연도 네비게이션 */}
                  <div className="flex items-center justify-between py-4 px-6 border-b">
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => navigateYear('prev')}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    
                    <h2 className="text-lg font-semibold">{currentYear}년</h2>
                    
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => navigateYear('next')}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* 헤더 - 이랑/월 */}
                  <div className="grid grid-cols-13 border-b bg-gray-50">
                    <div className="p-3 text-xs font-medium text-gray-600 border-r">
                      이랑/월
                    </div>
                    {Array.from({ length: 12 }, (_, i) => (
                      <div key={i} className="p-3 text-xs font-medium text-center border-r last:border-r-0">
                        {i + 1}
                      </div>
                    ))}
                  </div>

                  {/* 연간 작물 재배 현황 - 단순화된 레이아웃 */}
                  <div className="relative max-h-[600px] overflow-y-auto border border-gray-300">
                    {/* 헤더 */}
                    <div className="sticky top-0 bg-white border-b border-gray-300 flex">
                      <div className="w-12 p-2 text-xs font-medium text-gray-600 bg-gray-50 border-r border-gray-300 flex items-center justify-center">
                        이랑/월
                      </div>
                      {Array.from({ length: 12 }, (_, i) => (
                        <div key={i} className="flex-1 p-1 text-xs font-medium text-gray-600 bg-gray-50 border-r last:border-r-0 border-gray-300 flex items-center justify-center">
                          {i + 1}
                        </div>
                      ))}
                    </div>

                    {/* 데이터 행들 */}
                    {Array.from({ length: rowCount }, (_, rowIndex) => {
                      // 해당 이랑의 작물 데이터 계산
                      const getRowCropData = () => {
                        if (!crops || !farms || !tasks) return [];
                        
                        const currentFarm = farms.find(farm => 
                          farm.environment === selectedEnvironment || 
                          (selectedEnvironment === '노지' && farm.name.includes('노지'))
                        );

                        if (!currentFarm) return [];

                        // 해당 이랑의 작물들과 재배 기간 찾기
                        const rowCrops = crops.filter((crop, cropIndex) => {
                          const assignedRow = cropIndex % rowCount;
                          return assignedRow === rowIndex;
                        });

                        const cropPeriods = [];
                        
                        rowCrops.forEach(crop => {
                          const cropTasks = tasks.filter(task => 
                            task.cropId === crop.id && 
                            task.farmId === currentFarm.id
                          );

                          if (cropTasks.length > 0) {
                            // 작물의 시작월과 끝월 계산
                            const taskDates = cropTasks.map(task => new Date(task.scheduledDate || task.endDate));
                            const startMonth = Math.min(...taskDates.map(date => date.getMonth()));
                            const endMonth = Math.max(...taskDates.map(date => date.getMonth()));
                            
                            const colors = [
                              'bg-orange-200', 'bg-blue-200', 'bg-pink-200', 'bg-green-200',
                              'bg-yellow-200', 'bg-purple-200', 'bg-indigo-200', 'bg-red-200'
                            ];
                            
                            cropPeriods.push({
                              name: crop.name || crop.category,
                              startMonth,
                              endMonth,
                              color: colors[crops.findIndex(c => c.id === crop.id) % colors.length],
                              span: endMonth - startMonth + 1
                            });
                          }
                        });

                        return cropPeriods;
                      };

                      const cropPeriods = getRowCropData();
                      
                      return (
                        <div key={rowIndex} className="flex border-b border-gray-200 relative h-8">
                          {/* 이랑 번호 */}
                          <div className="w-12 p-1 text-xs font-medium text-gray-700 bg-gray-50 border-r border-gray-300 flex items-center justify-center">
                            {rowIndex + 1}
                          </div>
                          
                          {/* 월별 그리드 */}
                          <div className="flex-1 flex relative">
                            {Array.from({ length: 12 }, (_, monthIndex) => (
                              <div key={monthIndex} className="flex-1 border-r last:border-r-0 border-gray-300 h-8"></div>
                            ))}
                            
                            {/* 작물 배지들을 절대 위치로 배치 */}
                            {cropPeriods.map((crop, cropIndex) => {
                              const leftPosition = (crop.startMonth / 12) * 100;
                              const width = (crop.span / 12) * 100;
                              
                              return (
                                <Badge
                                  key={cropIndex}
                                  className={`absolute ${crop.color} border border-gray-800 rounded text-xs font-medium text-gray-800 px-1 py-0 h-6 flex items-center justify-center top-1`}
                                  style={{
                                    left: `${leftPosition}%`,
                                    width: `${Math.max(width, 8)}%`,
                                  }}
                                >
                                  <span className="truncate text-[8px]">{crop.name}</span>
                                </Badge>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}

                    {/* 스크롤바 영역 */}
                    <div className="absolute right-0 top-0 w-3 h-full bg-gray-200">
                      <div className="w-2 h-20 bg-gray-500 rounded mx-auto mt-2"></div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}