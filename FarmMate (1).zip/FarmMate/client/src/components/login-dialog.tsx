// client/src/components/login-dialog.tsx
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { signInWithGoogle } from "../lib/auth";
import { LogIn, User, AlertCircle } from "lucide-react";
import { useAuth } from "../contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";

interface LoginDialogProps {
  children?: React.ReactNode;
}

export function LoginDialog({ children }: LoginDialogProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { currentUser } = useAuth();
  const { toast } = useToast();

  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setError(null);
    try {
      await signInWithGoogle();
      setOpen(false);
      toast({
        title: "로그인 성공",
        description: "농장 관리 시스템에 성공적으로 로그인했습니다.",
      });
    } catch (error: any) {
      console.error("로그인 오류:", error);
      const errorMessage = getErrorMessage(error);
      setError(errorMessage);
      toast({
        title: "로그인 실패",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getErrorMessage = (error: any): string => {
    if (error.code === 'auth/popup-closed-by-user') {
      return "로그인 창이 닫혔습니다. 다시 시도해주세요.";
    }
    if (error.code === 'auth/popup-blocked') {
      return "팝업이 차단되었습니다. 브라우저 설정을 확인해주세요.";
    }
    if (error.code === 'auth/cancelled-popup-request') {
      return "로그인이 취소되었습니다.";
    }
    if (error.code === 'auth/network-request-failed') {
      return "네트워크 연결을 확인해주세요.";
    }
    return "로그인 중 오류가 발생했습니다. 다시 시도해주세요.";
  };

  // 이미 로그인된 경우 children을 렌더링
  if (currentUser) {
    return <>{children}</>;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {children || (
          <Button variant="outline" size="sm">
            <LogIn className="w-4 h-4 mr-2" />
            로그인
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>로그인</DialogTitle>
          <DialogDescription>
            농장 관리 시스템에 로그인하여 모든 기능을 이용하세요.
          </DialogDescription>
        </DialogHeader>
        <div className="flex flex-col space-y-4 pt-4">
          {error && (
            <div className="flex items-center gap-2 p-3 text-sm text-destructive bg-destructive/10 rounded-md">
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </div>
          )}
          <Button
            onClick={handleGoogleSignIn}
            disabled={isLoading}
            className="w-full"
            size="lg"
          >
            <User className="w-5 h-5 mr-2" />
            {isLoading ? "로그인 중..." : "Google로 로그인"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}